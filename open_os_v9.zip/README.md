# open-os
Quick access to any local large language model from your browser.
 
This beta is configured for Ollama models. Other providers, such as the ChatGPT API, will be added as they become available.

Simply click on the extension icon and start chatting with your virtual assistant. You can customize the personality of your bot with pre-prompts, making it more personalized and engaging. All these settings will be synchronized in all your browsers.

Extension has been developed and is maintained by @luishg with the help of ChatGPT and Github Copilot. The source code will be available soon.

For more info visit https://www.open-os.com
